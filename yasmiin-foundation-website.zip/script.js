const menuBtn=document.querySelector('.menu-btn'), navLinks=document.querySelector('.nav-links');
menuBtn.addEventListener('click',()=>{const open=navLinks.classList.toggle('open');menuBtn.setAttribute('aria-expanded',open)});
document.querySelectorAll('.nav-links a').forEach(a=>a.addEventListener('click',()=>navLinks.classList.remove('open')));

const slides=[...document.querySelectorAll('.hero-img')], dots=[...document.querySelectorAll('.dot')];
let current=0;
function showSlide(i){current=(i+slides.length)%slides.length;slides.forEach((s,n)=>s.classList.toggle('active',n===current));dots.forEach((d,n)=>d.classList.toggle('active',n===current))}
document.querySelector('.prev').onclick=()=>showSlide(current-1);
document.querySelector('.next').onclick=()=>showSlide(current+1);
dots.forEach((d,i)=>d.onclick=()=>showSlide(i));
setInterval(()=>showSlide(current+1),6500);

const modal=document.getElementById('donateModal');
document.querySelectorAll('[data-open-donate]').forEach(b=>b.onclick=()=>{modal.classList.add('open');modal.setAttribute('aria-hidden','false')});
document.querySelector('.modal-close').onclick=()=>{modal.classList.remove('open');modal.setAttribute('aria-hidden','true')};
modal.addEventListener('click',e=>{if(e.target===modal)modal.classList.remove('open')});
let amount='$50';
const selected=document.getElementById('selectedAmount'), donateEmail=document.getElementById('donateEmail');
document.querySelectorAll('[data-amount]').forEach(btn=>btn.onclick=()=>{amount=btn.dataset.amount;selected.textContent=amount;document.querySelectorAll('[data-amount]').forEach(x=>x.classList.remove('selected'));btn.classList.add('selected');donateEmail.href='mailto:info@yasmiinfoundation.org?subject=Donation%20to%20Yasmiin%20Foundation&body=I%20would%20like%20to%20donate%20'+encodeURIComponent(amount)+'.'});

document.getElementById('contactForm').addEventListener('submit',e=>{
 e.preventDefault();
 const f=e.currentTarget, data=new FormData(f);
 const subject=encodeURIComponent('Website inquiry from '+data.get('name'));
 const body=encodeURIComponent('Name: '+data.get('name')+'\nEmail: '+data.get('email')+'\n\n'+data.get('message'));
 window.location.href='mailto:info@yasmiinfoundation.org?subject='+subject+'&body='+body;
 document.getElementById('formNote').textContent='Opening your email app to send the message…';
});
document.getElementById('year').textContent=new Date().getFullYear();
